# MC2 Data description

The file format for the MC2 data.

## Schema

Derived from data:

```json
{
   "description": "string",
   "events": [
      {
         "short_name": "string",
         "parties": "array",
         "when": "float",
         "details": "object",
         "id": "int"
      }
   ]
}
```

## Key event:

The anomolous posting is sent to SaidIt by John Windward on May 17, 2046 at 4:21am.